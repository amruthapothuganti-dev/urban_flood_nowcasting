# TriForce Urban Flood Nowcasting System — Beginner Prototype

A Flask web application that demonstrates the project idea by combining:
- Rainfall intensity
- Drainage capacity
- Terrain / low-lying risk
- Zone-level risk scores and sample alerts

## Important limitation
This is an educational prototype using simulated sample data and a transparent rule-based score. It is **not** a validated hydrological model, trained AI/ML system, live flood map, or official emergency warning. Do not use it for real-world safety decisions.

## Run on Windows
1. Install Python 3.10 or newer from https://www.python.org/downloads/
2. Extract this ZIP folder.
3. Open the extracted `TriForce_Urban_Flood_Prototype` folder.
4. Click the folder address bar in File Explorer, type `cmd`, and press Enter.
5. Create a virtual environment:
   ```bat
   py -m venv .venv
   .venv\Scripts\activate
   ```
6. Install Flask:
   ```bat
   pip install -r requirements.txt
   ```
7. Start the app:
   ```bat
   python app.py
   ```
8. Open `http://127.0.0.1:5000` in your browser.
9. To stop the server, return to the terminal and press `Ctrl+C`.

## Run on macOS / Linux
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
Then open http://127.0.0.1:5000.

## How the demo score works
- Rainfall contributes up to 50 points.
- Low drainage capacity contributes up to 30 points.
- Terrain risk contributes up to 20 points.
- Score 0–34: Low; 35–64: Moderate; 65–100: High.

These weights and thresholds are illustrative and must be calibrated against reliable local data before any serious use.

## Project structure
```text
TriForce_Urban_Flood_Prototype/
├── app.py
├── requirements.txt
├── README.md
├── data/
│   └── sample_zones.csv
├── templates/
│   └── dashboard.html
└── static/
    └── style.css
```

## Next development steps
1. Replace sample rows with verified historical observations.
2. Add real geographic coordinates and a Leaflet map.
3. Add weather data with clear source and timestamps.
4. Compare predictions against recorded flood events.
5. Only then evaluate a machine-learning model and alert delivery.
