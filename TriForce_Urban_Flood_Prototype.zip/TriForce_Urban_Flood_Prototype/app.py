from flask import Flask, render_template, request
import csv
import os

app = Flask(__name__)
DATA_FILE = os.path.join(os.path.dirname(__file__), "data", "sample_zones.csv")

def load_zones():
    zones = []
    with open(DATA_FILE, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            row["rainfall"] = float(row["rainfall"])
            row["drainage_capacity"] = float(row["drainage_capacity"])
            row["terrain_risk"] = float(row["terrain_risk"])
            row["score"], row["risk"], row["action"] = calculate_risk(
                row["rainfall"], row["drainage_capacity"], row["terrain_risk"]
            )
            zones.append(row)
    return zones

def calculate_risk(rainfall, drainage_capacity, terrain_risk):
    """
    DEMONSTRATION RULES ONLY — not a validated flood forecast.
    rainfall: mm/hour (0–150)
    drainage_capacity: 0–100 (higher means better capacity)
    terrain_risk: 0–100 (higher means more low-lying / accumulation-prone)
    """
    rain_score = min(max(rainfall, 0), 150) / 150 * 50
    drainage_score = (100 - min(max(drainage_capacity, 0), 100)) / 100 * 30
    terrain_score = min(max(terrain_risk, 0), 100) / 100 * 20
    score = round(rain_score + drainage_score + terrain_score)

    if score >= 65:
        return score, "High", "Avoid the area if possible; notify local authorities."
    if score >= 35:
        return score, "Moderate", "Use caution and monitor conditions."
    return score, "Low", "Continue monitoring; no elevated risk in this demo."

@app.route("/", methods=["GET", "POST"])
def dashboard():
    zones = load_zones()
    result = None
    form = {"zone": "Sector 12 Underpass", "rainfall": 45, "drainage_capacity": 45, "terrain_risk": 70}

    if request.method == "POST":
        form["zone"] = request.form.get("zone", "Custom Test Zone")
        try:
            form["rainfall"] = float(request.form.get("rainfall", 0))
            form["drainage_capacity"] = float(request.form.get("drainage_capacity", 50))
            form["terrain_risk"] = float(request.form.get("terrain_risk", 50))
            if not (0 <= form["rainfall"] <= 150):
                raise ValueError("Rainfall must be between 0 and 150 mm/hour.")
            if not (0 <= form["drainage_capacity"] <= 100):
                raise ValueError("Drainage capacity must be between 0 and 100.")
            if not (0 <= form["terrain_risk"] <= 100):
                raise ValueError("Terrain risk must be between 0 and 100.")
            score, risk, action = calculate_risk(
                form["rainfall"], form["drainage_capacity"], form["terrain_risk"]
            )
            result = {"score": score, "risk": risk, "action": action, "zone": form["zone"]}
        except ValueError as e:
            result = {"error": str(e)}

    counts = {
        "high": sum(z["risk"] == "High" for z in zones),
        "moderate": sum(z["risk"] == "Moderate" for z in zones),
        "low": sum(z["risk"] == "Low" for z in zones),
    }
    return render_template("dashboard.html", zones=zones, counts=counts, result=result, form=form)

if __name__ == "__main__":
    app.run(debug=True)
